﻿using SportApp.models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SportApp.Classes
{
    class connect
    {
        public static models.Sport_AppEntities1 modelbd;

        public static Sport_AppEntities1 modeldb { get; internal set; }
    }
}
